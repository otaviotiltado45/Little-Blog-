import styled, { createGlobalStyle } from 'styled-components';
export const GlobalStyle = createGlobalStyle`
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
`;

export const FormWrapper = styled.form`
  display: flex;
  flex-direction: column;
  margin: 20px;
`;

export const Input = styled.input`
  margin: 10px 0;
  padding: 10px;
  font-size: 16px;
`;

export const Button = styled.button`
  padding: 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  cursor: pointer;
`;

export const DeleteButton = styled(Button)`
  background-color: red;
  margin-top: 10px;
`;

export const ListWrapper = styled.div`
  display: flex;
  flex-direction: column;
  margin: 20px;
`;

export const PostWrapper = styled.div`
  display: flex;
  border: 1px solid #ccc;
  margin: 10px 0;
  padding: 10px;
`;

export const PostImage = styled.img`
  width: 40%;
  height: 100%;
`;

export const PostContent = styled.div`
  width: 60%;
  padding: 10px;
`;

export const ModalWrapper = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const ModalContent = styled.div`
  background-color: white;
  padding: 20px;
  width: 500px;
  height: 300px;
  overflow-y: scroll;
`;

export const CloseButton = styled(Button)`
  background-color: gray;
`;

export const Footer = styled.footer`
  display: flex;
  justify-content: center;
  margin-top: 20px;

  a {
    color: #007bff;
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }
`;