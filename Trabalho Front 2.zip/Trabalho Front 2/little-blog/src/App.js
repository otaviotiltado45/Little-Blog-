import React, { useState } from 'react';
import PostList from './components/PostList';
import PostForm from './components/PostForm';
import { GlobalStyle } from './styles/PostStyles';

function App() {
  const [posts, setPosts] = useState([]);

  const addPost = (post) => {
    setPosts([post, ...posts]);
  };

  const deletePost = (id) => {
    setPosts(posts.filter((post, index) => index !== id));
  };

  return (
    <div>
      <GlobalStyle />
      <PostForm addPost={addPost} />
      <PostList posts={posts} deletePost={deletePost} />
    </div>
  );
}

export default App;
