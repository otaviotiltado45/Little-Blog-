import React from 'react';
import { ModalWrapper, ModalContent, CloseButton } from '../styles/PostStyles';

function Modal({ content, onClose }) {
  return (
    <ModalWrapper>
      <ModalContent>
        <p>{content}</p>
        <CloseButton onClick={onClose}>Fechar</CloseButton>
      </ModalContent>
    </ModalWrapper>
  );
}

export default Modal;