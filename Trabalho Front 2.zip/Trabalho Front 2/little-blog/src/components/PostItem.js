import React, { useState } from 'react';
import Modal from './Modal';
import { PostWrapper, PostImage, PostContent, Button, DeleteButton } from '../styles/PostStyles';


const defaultImage = '/defaultImage.png';

function PostItem({ post, id, deletePost }) {
  const [showModal, setShowModal] = useState(false);
  const truncatedContent = post.content.length > 100 ? post.content.substring(0, 500) + '...' : post.content;

  return (
    <PostWrapper>
      <PostImage src={post.image || defaultImage} alt={post.title} />
      <PostContent>
        <h2>{post.title}</h2>
        <p>{truncatedContent}</p>
        {post.content.length > 100 && <Button onClick={() => setShowModal(true)}>Leia mais</Button>}
        <DeleteButton onClick={() => deletePost(id)}>Deletar</DeleteButton>
      </PostContent>
      {showModal && <Modal content={post.content} onClose={() => setShowModal(false)} />}
    </PostWrapper>
  );
}

export default PostItem;
