import React, { useState } from 'react';
import { FormWrapper, Input, Button, Footer } from '../styles/PostStyles';

function PostForm({ addPost }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [image, setImage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title.length > 50) {
      alert('O título deve ter no máximo 50 caracteres.');
      return;
    }
    const newPost = { title, content, image };
    addPost(newPost);
    setTitle('');
    setContent('');
    setImage('');
  };

  return (
    <>
      <FormWrapper onSubmit={handleSubmit}>
        <h1>Little Blog</h1>
        <Input
          type="text"
          placeholder="Título"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <Input
          type="text"
          placeholder="Conteúdo"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
        <Input
          type="text"
          placeholder="URL da Imagem (opcional)"
          value={image}
          onChange={(e) => setImage(e.target.value)}
        />
        <Button type="submit">Postar</Button>
      </FormWrapper>
      <Footer>
        <a href="https://www.myinstants.com/pt/index/br/" target="" rel="audios estranhos">Clique aqui para saber mais</a>
      </Footer>
    </>
  );
}

export default PostForm;
