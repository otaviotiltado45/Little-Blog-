import React from 'react';
import PostItem from './PostItem';
import { ListWrapper } from '../styles/PostStyles';

function PostList({ posts, deletePost }) {
  return (
    <ListWrapper>
      {posts.map((post, index) => (
        <PostItem key={index} post={post} id={index} deletePost={deletePost} />
      ))}
    </ListWrapper>
  );
}

export default PostList;
